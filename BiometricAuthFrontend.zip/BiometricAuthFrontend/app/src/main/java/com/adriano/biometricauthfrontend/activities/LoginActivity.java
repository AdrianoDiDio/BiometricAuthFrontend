package com.adriano.biometricauthfrontend.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.adriano.biometricauthfrontend.R;
import com.adriano.biometricauthfrontend.fragments.LoginFragment;

import timber.log.Timber;

/*
* TODO:
*  Login/Register Fragment
*  Main Content Fragment which contains:
*        -Main view to show details about current user.
*        -Bottom Navigation Bar.
*        -Settings to enroll fingerprint.
*
* */
public class LoginActivity extends AppCompatActivity {
    private LoginFragment loginFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

//        loginFragment = new LoginFragment();
//        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
//        fragmentTransaction.replace(R.id.FragmentContainer, loginFragment);
//        fragmentTransaction.addToBackStack(null);
//        fragmentTransaction.commit();
    }
}